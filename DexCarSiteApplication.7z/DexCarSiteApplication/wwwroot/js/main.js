﻿var isMouseIn = false;

function SetMargin() {
    $('nav').css('opacity', '1');
    //$('nav').removeClass('minusmg');
    if (!isMouseIn && (window.pageYOffset || document.documentElement.scrollTop)) {
        //$('nav').addClass('minusmg');
        $('nav').css('opacity', '0');


    }
}
var linkstate = false;
function ReadMore() {
    $('.learnbutton').show();
    if (!linkstate) {
        //$('.about_us').css('height', '100%');
        $('#about .fontmdsize').css('height', '12rem');
        //$('.learnbutton span').replaceWith("<span id='id6'>Learn more...<span>");
    }
    else {
        //$('.about_us').css('height', $('#about img').height());
        $('#about .fontmdsize').css('height', '100%');



        //$('.learnbutton span').replaceWith("<span id='id7'>hide<span>");
    }

}


function setNavigation() {
    var path = window.location.pathname;
    path = path.replace(/\/$/, '');
    path = decodeURIComponent(path);
    var xxx = path.split('/');
    if ($(document).width() >= 1200) {
        if (path !== '') {
            var hrefs = $('nav.navbar .nav-item a[href*="' + xxx[1] + '"]');
            $(hrefs[0]).addClass('activeclass');
            $('.activeclass').parent().css(
                "border-bottom", "solid #C74242 3px");
        }
    }
}

var jtrnsl;
function translate(toLang) {
    var str = jtrnsl.eng;
    if (toLang === "en") {
        str = jtrnsl.eng;
    } else
        if (toLang === "ru") {
            str = jtrnsl.rus;
        }
    var idcollection = $('[id]');
    for (var i = 0; i < idcollection.length; i++) {
        if (str[$(idcollection[i]).prop('id')] !== "") {
            //if ($(idcollection[i]).is('input')) {
            //    $(idcollection[i]).prop('placeholder', str[$(idcollection[i]).prop('id')]);
            //} else {
            //    $(idcollection[i]).text(str[$(idcollection[i]).prop('id')]);
            //}
            $(idcollection[i]).text(str[$(idcollection[i]).prop('id')]);
        }
    }
}

function HeightNavbarCalculate() {
var navbarheight = $(window).height();
$('#navbarCollapse').height(navbarheight);

}

function SingleValidation() {
    let self = this;

    if (this.id === 'phone') {
        var regex = new RegExp(/\(?([0-9]{3})\)?([ .-]?)([0-9]{3})\2([0-9]{4})/);
        var OK = regex.test(this.value);
        if (!OK) {
            this.classList.add('is-invalid');
        } else {
            this.classList.add('is-valid');
        }
    }
    else {
        if (this.checkValidity() === false) {
            this.classList.add('is-invalid');
        } else {
            this.classList.add('is-valid');
        }
    }
    this.classList.add('was-validated');
    setTimeout(function () {

        self.classList.remove('was-validated');
        self.classList.remove('is-invalid');
        self.classList.remove('is-valid');

    }, 3000);

}


function MyValidation() {
    var inputs = document.querySelectorAll('form .form-control');
    var i;
    var result = true;
    for (i = 0; i < inputs.length; i++) {
        inputs[i].classList.remove('was-validated');
        inputs[i].classList.remove('is-invalid');

        if (inputs[i].id === 'phone') {
            var regex = new RegExp(/\(?([0-9]{3})\)?([ .-]?)([0-9]{3})\2([0-9]{4})/);
            var OK = regex.test(inputs[i].value);
            if (!OK) {
                result = false;
                inputs[i].classList.add('is-invalid');
            } else {
                inputs[i].classList.add('is-valid');
            }
        }
        else {
            if (inputs[i].checkValidity() === false) {
                result = false;
                inputs[i].classList.add('is-invalid');
            } else {
                inputs[i].classList.add('is-valid');
            }
        }
        inputs[i].classList.add('was-validated');
    }
    setTimeout(function () {
        var i;
        for (i = 0; i < inputs.length; i++) {
            inputs[i].classList.remove('was-validated');
            inputs[i].classList.remove('is-invalid');
            inputs[i].classList.remove('is-valid');
        }
    }, 3000);
    return result;
}

function SendEmail() {
    Email.send({
        SecureToken: "fb119663-5748-4990-9262-dd4e873679d3",
        To: 'vera.bakerova@mail.ru',
        Cc: 'verbapho@gmail.com',
        From: 'info@ggrealestate.by',
        Subject: "Someone has interested in the Dex@Service",
        Body: 'Dear Fabio!<br><br> You have got a message from ' + $('#usr').val() + ':<br>"' + $('#id23').val() + '"<br><br> their email: ' + $('#id21').val() + '<br><br> Yours,<br>  DexCar site.'
    }).then(function (res) {
        if (res === 'OK') {
            $('#deliveredModal').modal('show');
        } else {
            alert(res);
        }
    });
}

function SubmitClick() {
    if (!$(this).hasClass('loading')) {
        $(this).addClass('loading');
        let self = this;

        if (MyValidation()) {
            setTimeout(function () {
                $(self).removeClass('loading');
                $(self).addClass('checked');
            }, 1500);

            // send email
            SendEmail();
            $('form .form-control').val('');
            $('form .form-control').removeClass('is-valid');

        }
        else {
            setTimeout(function () {
                $(self).removeClass('loading');
                $(self).addClass('failed');
            }, 1500);
        }
        setTimeout(function () {
            $(self).removeClass('checked');
            $(self).removeClass('failed');
        }, 3000);
    }
}

$(document).ready(function () {
    $.getJSON('/js/datatextj.json', function (jd) {
        jtrnsl = jd;
        var toLang = navigator.language.substr(0, 2);
        if (toLang !== 'en' && toLang !== 'ru') {
            toLang = 'en';
        }
        $("#" + toLang).change();
    }).fail(function () {
        console.log("error");
    });

    $('.internalize').on('change', function () {
        var lang = $(".internalize option:selected").val();
        translate(lang);
    });



    $('.margint').css('margin-top', $('.mynavmenu').height());
    $('.cookieConsent.margint').css('margin-top', $('nav.mynavmenu').height() + 54);
    $('#about .fontmdsize').css('height', '12rem');
    SetMargin();
    ReadMore();

    $(window).scroll(SetMargin);

    $('nav').on('mouseenter', function () {
        isMouseIn = true;
        SetMargin();
    });
    $('nav').on('mouseleave', function () {
        isMouseIn = false;
        SetMargin();
    });

    $('.learnbutton').on('click', function () {
        linkstate = !linkstate;
        ReadMore();
        $(this).hide();
        $('a.learnbutton:visited').hide();
    });

    setNavigation();
    $('nav.navbar .nav-item').on('click', setNavigation);

    $('#navbarCollapse').on('shown.bs.collapse', HeightNavbarCalculate);
    $('#navbarCollapse').on('hide.bs.collapse', HeightNavbarCalculate);
    $('#navbarCollapse').on('hidden.bs.collapse', HeightNavbarCalculate);
  
    

    function getBootstrapDeviceSize() {
        return $('.internalize option').find('option.d-block').first().attr('id');
    }


    $('#id24').on('click', SubmitClick);
    $('form .form-control').on('blur', SingleValidation);


});


