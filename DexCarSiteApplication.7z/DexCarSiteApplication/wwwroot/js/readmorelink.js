﻿var linkstate = false;
function ReadMore() {
    $('.learnbutton').show();
    if (!linkstate) {
        //$('.about_us').css('height', '100%');
        $('#about .fontmdsize').css('height', '11.875rem');
        //$('.learnbutton span').replaceWith("<span id='id6'>Learn more...<span>");
    }
    else {
        //$('.about_us').css('height', $('#about img').height());
        $('#about .fontmdsize').css('height', '100%');



        //$('.learnbutton span').replaceWith("<span id='id7'>hide<span>");
    }

}


$(document).ready(function () {
    $('#about .fontmdsize').css('height', '11.875rem');
    ReadMore();



    $('.learnbutton').on('click', function () {
        linkstate = !linkstate;
        ReadMore();
        $(this).hide();
        $('a.learnbutton:visited').hide();
        //$(this).hide();
    });
}